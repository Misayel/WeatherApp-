//
//  City.swift
//  WeatherApp
//
//  Created by Misayel Gezahegn on 6/1/17.
//  Copyright © 2017 . All rights reserved.
//

struct City {

    let name: String
    
}
